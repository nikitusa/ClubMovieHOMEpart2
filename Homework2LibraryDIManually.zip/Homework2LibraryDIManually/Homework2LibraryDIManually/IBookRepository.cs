﻿using System.Collections.Generic;
using System.Threading.Tasks;

public interface IBookRepository
{
    Task<List<Book>> GetAllAsync();
}