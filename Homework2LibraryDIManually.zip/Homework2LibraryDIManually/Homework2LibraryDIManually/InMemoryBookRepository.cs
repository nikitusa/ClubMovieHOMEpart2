﻿using System.Collections.Generic;
using System.Threading.Tasks;

public class InMemoryBookRepository : IBookRepository
{
    private readonly List<Book> _books = new()
    {
        new Book(1, "Война и мир", "Лев Толстой"),
        new Book(2, "Анна Каренина", "Лев Толстой"),
        new Book(3, "Преступление и наказание", "Фёдор Достоевский")
    };

    public async Task<List<Book>> GetAllAsync()
    {
        return _books;
    }
}