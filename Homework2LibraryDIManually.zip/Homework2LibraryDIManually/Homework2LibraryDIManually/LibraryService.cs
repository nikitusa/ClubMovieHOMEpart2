﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

public class LibraryService
{
    private readonly IBookRepository _repository;

    public LibraryService(IBookRepository repository)
    {
        _repository = repository;
    }

    public async Task PrintAllAsync()
    {
        var books = await _repository.GetAllAsync();
        foreach (var book in books)
        {
            Console.WriteLine($"{book.Title} - {book.Author}");
        }
    }
}