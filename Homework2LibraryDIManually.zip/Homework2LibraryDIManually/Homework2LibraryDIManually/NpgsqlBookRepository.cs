﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Npgsql;

public class NpgsqlBookRepository : IBookRepository
{
    private readonly string _connectionString;

    public NpgsqlBookRepository(string connectionString)
    {
        _connectionString = connectionString;
    }

    public async Task<List<Book>> GetAllAsync()
    {
        var optionsBuilder = new DbContextOptionsBuilder<LibraryDbContext>();
        optionsBuilder.UseNpgsql(_connectionString);

        using var context = new LibraryDbContext(optionsBuilder.Options);
        return await context.Books.ToListAsync();
    }
}


public class LibraryDbContext : DbContext
{
    public DbSet<Book> Books { get; set; }

    public LibraryDbContext(DbContextOptions<LibraryDbContext> options) : base(options) { }
}