﻿using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
       
        IBookRepository repository = new InMemoryBookRepository(); 
        var library = new LibraryService(repository);
        await library.PrintAllAsync();
    }
}